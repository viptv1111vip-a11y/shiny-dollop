package main

import (
	"log"
	"net/http"
	"github.com/gorilla/mux"
	"kgz_backend/internal/database"
)

func main() {
	log.Println("Запуск бэкенд-сервера KGZ Mobile...")

	// Инициализация подключения к PostgreSQL
	database.InitDB()

	r := mux.NewRouter()

	// Регистрация маршрутов API
	r.HandleFunc("/api/auth/register", RegisterHandler).Methods("POST")
	r.HandleFunc("/api/auth/login", LoginHandler).Methods("POST")
	r.HandleFunc("/api/player/loot", GetLootHandler).Methods("GET")

	// Запуск сервера на порту 8080
	log.Println("API Сервер успешно запущен на порту :8080")
	if err := http.ListenAndServe(":8080", r); err != nil {
		log.Fatalf("Ошибка запуска сервера: %v", err)
	}
}

// Заглушки для обработчиков (реализация в следующих файлах)
func RegisterHandler(w http.ResponseWriter, r *http.Request) {}
func LoginHandler(w http.ResponseWriter, r *http.Request)    {}
func GetLootHandler(w http.ResponseWriter, r *http.Request)     {}
