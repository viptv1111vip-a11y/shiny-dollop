package database

import (
	"database/sql"
	"fmt"
	"log"
	_ "github.com/lib/pq"
)

var DB *sql.DB

func InitDB() {
	// Строка подключения к PostgreSQL (настройки для Docker)
	connStr := "host=db user=kgz_admin password=kgz_secure_pass dbname=kgz_mobile sslmode=disable"
	
	var err error
	DB, err = sql.Open("postgres", connStr)
	if err != nil {
		log.Fatalf("Ошибка открытия базы данных: %v", err)
	}

	// Проверка соединения
	err = DB.Ping()
	if err != nil {
		log.Fatalf("База данных недоступна: %v", err)
	}

	log.Println("Успешное подключение к PostgreSQL.")
	createTables()
}

func createTables() {
	// Создание таблицы пользователей и их временного склада "добычи"
	query := `
	CREATE TABLE IF NOT EXISTS players (
		id SERIAL PRIMARY KEY,
		username VARCHAR(32) UNIQUE NOT NULL,
		password_hash VARCHAR(64) NOT NULL,
		money INT DEFAULT 5000,
		level INT DEFAULT 1,
		loot_items JSONB DEFAULT '[]'::jsonb
	);`
	
	_, err := DB.Exec(query)
	if err != nil {
		log.Fatalf("Ошибка создания таблиц в БД: %v", err)
	}
}
