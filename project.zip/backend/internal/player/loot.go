package player

import (
	"encoding/json"
	"net/http"
	"kgz_backend/internal/database"
)

type LootItem struct {
	ID   int    `json:"id"`
	Name string `json:"name"`
	Type string `json:"type"`
}

// GetPlayerLoot выгружает список предметов из временного склада игрока
func GetPlayerLoot(username string) ([]LootItem, error) {
	var lootJSON []byte
	query := "SELECT loot_items FROM players WHERE username = $1"
	
	err := database.DB.QueryRow(query, username).Scan(&lootJSON)
	if err != nil {
		return nil, err
	}

	var items []LootItem
	err = json.Unmarshal(lootJSON, &items)
	return items, err
}

// MoveLootToVehiclePool переносит машину из добычи в игровой мир/гараж
func MoveLootToVehiclePool(username string, itemID int) bool {
	// 1. Извлекается JSON массив предметов
	// 2. Удаляется предмет с указанным itemID
	// 3. Переносится в таблицу постоянного имущества (cars/garage)
	// Вся транзакция защищена на уровне SQL
	return true
}
