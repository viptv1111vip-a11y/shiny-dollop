// Shader declarations
