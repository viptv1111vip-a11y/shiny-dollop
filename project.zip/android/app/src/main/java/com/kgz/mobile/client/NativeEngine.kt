package com.kgz.mobile.client

import android.util.Log

object NativeEngine {
    init {
        try {
            System.loadLibrary("kgz_core")
            Log.i("KGZ_NATIVE", "Нативная библиотека kgz_core успешно загружена.")
        } catch (e: UnsatisfiedLinkError) {
            Log.e("KGZ_NATIVE", "Критическая ошибка загрузки библиотеки: ${e.message}")
        }
    }

    // Запуск сетевого клиента и подключение к серверу
    external fun startNetworkClient(ip: String, port: Int)

    // Обработка сетевого кадра и тиков синхронизации (вызывать в основном цикле)
    external fun processClientFrame()
}